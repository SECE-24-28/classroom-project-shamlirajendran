const userModel = require("../model/User");

// GET all users
exports.getUser = async (req, res) => {
    try {
        const users = await userModel.find();
        res.json(users);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Server error" });
    }
};

// POST user (Register)
exports.postUser = async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const newUser = new userModel({ name, email, password });
        await newUser.save();
        res.status(201).json(newUser);
    } catch (error) {
        console.error("Error in posting user");
        res.status(500).json({ error: "Server error" });
    }
};

// LOGIN user
exports.loginUser = async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await userModel.findOne({ email, password });
        if (!user) {
            return res.status(401).json({ message: "Invalid email or password" });
        }
        res.json({ message: "Login successful", user });
    } catch (error) {
        console.error("Login error");
        res.status(500).json({ error: "Server error" });
    }
};

// UPDATE user
exports.updateUser = async (req, res) => {
    const id = req.params.id;
    const { name, email, password } = req.body;

    try {
        const updated = await userModel.findByIdAndUpdate(
            id,
            { name, email, password },
            { new: true }
        );

        if (!updated) {
            return res.status(404).json({ message: "User not found" });
        }
        res.json(updated);
    } catch (error) {
        console.error("Update error");
        res.status(500).json({ error: "Server error" });
    }
};

// DELETE user
exports.deleteUser = async (req, res) => {
    const id = req.params.id;
    try {
        const deleted = await userModel.findByIdAndDelete(id);
        if (!deleted) {
            return res.status(404).json({ message: "User not found" });
        }
        res.status(204).json({ message: "User deleted" });
    } catch (error) {
        console.error("Delete error");
        res.status(500).json({ error: "Server error" });
    }
};
