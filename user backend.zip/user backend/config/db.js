const mongoose = require("mongoose");
const dotenv = require("dotenv");
dotenv.config();

const connectdb = async () => {
    try {
        console.log("Connecting to MongoDB...");
        await mongoose.connect(process.env.MONGO_URL, {
            serverSelectionTimeoutMS: 10000,
        });
        console.log("✅ Database Connected");
    } catch (error) {
        console.error("❌ DB Error:", error.message);
        process.exit(1);
    }
};

module.exports = connectdb;
