const express = require("express");
const router = express.Router();
const {
    getUser,
    postUser,
    loginUser,
    updateUser,
    deleteUser
} = require("../controller/userController");

router.get("/getuser", getUser);
router.post("/postuser", postUser);
router.post("/login", loginUser);
router.put("/updateuser/:id", updateUser);
router.delete("/deleteuser/:id", deleteUser);

module.exports = router;
